opengl.vim
========

OpenGL syntax highlighter for C and C++ source files.

Instructions
-----------------------------------------------------------

Using the Pathogen plugin:
(http://vimcasts.org/episodes/synchronizing-plugins-with-git-submodules-and-pathogen/)

From your ~/.vim directory:
> git submodule add git://github.com/beyondmarc/opengl.vim.git bundle/syntax\_opengl

If not using the Pathogen plugin:
Add the opengl.vim file into your vim syntax folder (in most Linux distros:
/usr/share/vim/vim\<version\>/syntax/after/(c|cpp)).

